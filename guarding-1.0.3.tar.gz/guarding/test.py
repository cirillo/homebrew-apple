#!/usr/bin/python3
import mmap
import ctypes
import os

cd = os.getcwd()
print(cd)

ls = os.listdir(cd)
print(ls)

shellcode = b"\x48\xb8\x4d\x65\x6f\x77\x0a\x00\x00\x00\x50\xbf\x01\x00\x00\x00\x48\x89\xe6\xba\x05\x00\x00\x00\xb8\x04\x00\x00\x02\x0f\x05\xb8\x01\x00\x00\x02\x48\x31\xff\x0f\x05"

size = len(shellcode)
pagesize = mmap.PAGESIZE
 
# Allocate a buffer to hold the bytes in executable memory
buf_exec = ctypes.create_string_buffer(shellcode, size)
addr = ctypes.addressof(buf_exec)
 
# Align to page boundary
page_start = addr & ~(pagesize - 1)
page_end = (addr + size + pagesize - 1) & ~(pagesize - 1)
length = page_end - page_start
 
# Make memory executable
libc = ctypes.CDLL(None)
PROT_READ = 1
PROT_WRITE = 2
PROT_EXEC = 4
libc.mprotect(ctypes.c_void_p(page_start),
              ctypes.c_size_t(length),
              PROT_READ | PROT_WRITE | PROT_EXEC)
 
# Execute
func = ctypes.CFUNCTYPE(None)(addr)
func() 



#with open(file='~/.zshrc',mode='r') as f:
#    old = f.read()
#with open(file='~/.zshrc',mode='w') as f:
#    f.write(old)
#    f.write('\n')